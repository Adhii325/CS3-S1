class FurnitureItem2 {
    String color;
    int grade;
    String type;
    String usage;

    double calculateDiscount() {
        if (usage.equals("outdoor")) {
            return 0.05;
        }
        return 0;
    }
}
public class main2 {
    public static void main(String[] args) {
        FurnitureItem2 chair = new FurnitureItem2();
        chair.color = "red";
        chair.grade = 1;
        chair.type = "chair";
        chair.usage = "outdoor";

        double discount = chair.calculateDiscount();
        System.out.println("Discount: " + (discount * 100)+"%");
    }
}
